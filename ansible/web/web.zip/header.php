<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Allsafe Express</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/tables.css" rel="stylesheet" type="text/css" />
<link href="css/forms.css" rel="stylesheet" type="text/css" />
<link href="js/fullcalendar/fullcalendar.css" rel="stylesheet" type="text/css" />
<link href="js/fullcalendar/fullcalendar.print.css" rel="stylesheet" type="text/css" media="print" />
<link href="css/custom-theme/jquery-ui-1.8.11.custom.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script type="text/javascript" src="js/jquery-mask.js"></script>
<script type="text/javascript" src="js/jquery-tables.js"></script>
<script type="text/javascript" src="js/jquery-forms.js"></script>
<script type="text/javascript" src="js/ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="js/ckeditor/adapters/jquery.js"></script>
<script type="text/javascript" src="js/jquery-multiselect.js"></script>
<script type="text/javascript" src="js/fullcalendar/fullcalendar.min.js"></script>
<script type="text/javascript" src="js/main.js"></script>
</head>
<body>
	<div id="grid_header">	
		<div id="top">		
			<div id="logo">			
			Allsafe Express
                        </div>			
			<div id="mainmenu">		        
			</div>
		</div>		
		
		<div id="title">
			<div class="title_text">
				<h1>LOGISTICA<br />
				</h1>
			</div>
		</div>
	</div>
